﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data.SQLite;


namespace Polkupyörärekisteri_2._0
{
    public partial class Form1 : Form
    {
        private string dbPath;
        private List<Entry> entries;

        public Form1()
        {
            InitializeComponent();

            dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database.db");
            entries = new List<Entry>();
        }

        public class Entry
        {
            public int ID { get; set; }
            public string Nimi { get; set; }
            public string Malli { get; set; }
            public string Merkki { get; set; }
            public string Väri { get; set; }
            public int Vaihteet { get; set; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT ID, nimi, merkki, malli, väri, vaihteet FROM Tiedot";

                using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                {
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Entry newEntry = new Entry();

                            if (!reader.IsDBNull(0))
                            {
                                newEntry.ID = reader.GetInt32(0);
                            }

                            if (!reader.IsDBNull(1))
                            {
                                newEntry.Nimi = reader.GetString(1);
                            }

                            if (!reader.IsDBNull(2))
                            {
                                newEntry.Merkki = reader.GetString(2);
                            }

                            if (!reader.IsDBNull(3))
                            {
                                newEntry.Malli = reader.GetString(3);
                            }

                            if (!reader.IsDBNull(4))
                            {
                                newEntry.Väri = reader.GetString(4);
                            }

                            if (!reader.IsDBNull(5))
                            {
                                newEntry.Vaihteet = reader.GetInt32(5);
                            }

                            entries.Add(newEntry);
                        }
                    }
                }
            }

            foreach (Entry entry in entries)
            {
                listBox1.Items.Add($"{entry.Nimi} | {entry.Merkki} | {entry.Malli} | {entry.Väri} | vaihteet: {entry.Vaihteet}");
            }
        }


        private void btnok_Click1(object sender, EventArgs e)
        {

            string connectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";
            //korjais jo
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Tiedot (
                        ID INTEGER PRIMARY KEY AUTOINCREMENT,
                        nimi TEXT,
                        merkki TEXT,
                        malli TEXT,
                        väri TEXT,
                        vaihteet INTEGER
                )";

                using (SQLiteCommand command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }


            try
            {
                //luotetaan kaikki tiedot
                string Väri = txtväri.Text;
                string merkki = txtmerkki.Text;
                string malli = txtmalli.Text;
                int vaihde = int.Parse(txtvaihde.Text.ToString());

                var regexItem = new Regex("^[a-zA-Z 0-9]+$");

                //jos joku tyhjä virhe muuten jatketaan
                if (Väri == "" || merkki == "" || malli == "")
                {
                    MessageBox.Show("Joku kentistä jäi tyhjäksi");
                }
                else if (regexItem.IsMatch(Väri) == false || regexItem.IsMatch(merkki) == false || regexItem.IsMatch(malli) == false)
                {
                    MessageBox.Show("Kentissä voi olla vain kirjaimia tai numeroita");
                }
                else
                {
                    string nimi = txtOmistaja.Text;
                    //tarkistetaan että nimessä ei ole numeroita muuten virhe
                    var regexItemname = new Regex("^[a-zA-Z ]+$");
                    if (regexItemname.IsMatch(nimi))
                    {

                        using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();


                            string insertQuery = "INSERT INTO Tiedot (nimi, merkki, malli, väri, vaihteet) VALUES (@Nimi, @Merkki, @Malli, @Väri, @Vaihteet)";

                            using (SQLiteCommand command = new SQLiteCommand(insertQuery, connection))
                            {
                                // Replace values with your actual variables
                                command.Parameters.AddWithValue("@Nimi", nimi);
                                command.Parameters.AddWithValue("@Merkki", merkki);
                                command.Parameters.AddWithValue("@Malli", malli);
                                command.Parameters.AddWithValue("@Väri", Väri);
                                command.Parameters.AddWithValue("@Vaihteet", vaihde);

                                command.ExecuteNonQuery();
                                Form1 NewForm = new Form1();
                                NewForm.Show();
                                this.Dispose(false);

                            }
                            connection.Close();
                        }

                    }
                    else
                    {
                        MessageBox.Show("Nimessä voi olla vain kirjaimia tai se on tyhjä");
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Virhe!!  " + ex.Message);
            }

        }

        private void btnvaito_Click(object sender, EventArgs e)
        {
            string uusinimi = txtuusiomistaja.Text;
            //tarkistetaan että nimessä ei ole numeroita muuten virhe
            var regexItem = new Regex("^[a-zA-Z ]+$");
            if (regexItem.IsMatch(uusinimi))
            {

                string connectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    Entry selectedEntry = entries[listBox1.SelectedIndex];
                    int selectedEntryID = selectedEntry.ID;

                    string updateQuery = "UPDATE Tiedot SET nimi = @uusinimi WHERE ID = @EntryID";

                    using (SQLiteCommand command = new SQLiteCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@uusinimi", uusinimi);
                        command.Parameters.AddWithValue("@EntryID", selectedEntryID);

                        command.ExecuteNonQuery();
                        Form1 NewForm = new Form1();
                        NewForm.Show();
                        this.Dispose(false);
                    }
                }
            }
            else
            {
                MessageBox.Show("Uudessa nimessä voi olla vain kirjaimia tai se jäi tyhjäksi");
            }
        }

        private void btnpoista_Click(object sender, EventArgs e)
        {


            int poistettava = listBox1.SelectedIndex;

            if (listBox1.SelectedIndex != -1)
            {
                Entry selectedEntry = entries[listBox1.SelectedIndex];
                int selectedEntryID = selectedEntry.ID;

                string connectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";

                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string deleteQuery = "DELETE FROM Tiedot WHERE ID = @ID";

                    using (SQLiteCommand command = new SQLiteCommand(deleteQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ID", selectedEntryID);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            listBox1.Items.RemoveAt(listBox1.SelectedIndex); // Remove from ListBox
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete the entry.");
                        }
                    }
                }
            }
            Form1 NewForm = new Form1();
            NewForm.Show();
            this.Dispose(false);
        }
    }
}
