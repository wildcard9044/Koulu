﻿
namespace Polkupyörärekisteri_2._0
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnok = new System.Windows.Forms.Button();
            txtOmistaja = new System.Windows.Forms.TextBox();
            txtmerkki = new System.Windows.Forms.TextBox();
            txtmalli = new System.Windows.Forms.TextBox();
            txtväri = new System.Windows.Forms.TextBox();
            txtuusiomistaja = new System.Windows.Forms.TextBox();
            txtvaihde = new System.Windows.Forms.NumericUpDown();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            listBox1 = new System.Windows.Forms.ListBox();
            btnpoista = new System.Windows.Forms.Button();
            btnvaito = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)txtvaihde).BeginInit();
            SuspendLayout();
            // 
            // btnok
            // 
            btnok.Location = new System.Drawing.Point(168, 169);
            btnok.Name = "btnok";
            btnok.Size = new System.Drawing.Size(129, 62);
            btnok.TabIndex = 0;
            btnok.Text = "Lisää";
            btnok.UseVisualStyleBackColor = true;
            btnok.Click += btnok_Click1;
            // 
            // txtOmistaja
            // 
            txtOmistaja.Location = new System.Drawing.Point(12, 31);
            txtOmistaja.Name = "txtOmistaja";
            txtOmistaja.Size = new System.Drawing.Size(129, 23);
            txtOmistaja.TabIndex = 1;
            // 
            // txtmerkki
            // 
            txtmerkki.Location = new System.Drawing.Point(168, 31);
            txtmerkki.Name = "txtmerkki";
            txtmerkki.Size = new System.Drawing.Size(129, 23);
            txtmerkki.TabIndex = 2;
            // 
            // txtmalli
            // 
            txtmalli.Location = new System.Drawing.Point(328, 31);
            txtmalli.Name = "txtmalli";
            txtmalli.Size = new System.Drawing.Size(129, 23);
            txtmalli.TabIndex = 3;
            // 
            // txtväri
            // 
            txtväri.Location = new System.Drawing.Point(12, 110);
            txtväri.Name = "txtväri";
            txtväri.Size = new System.Drawing.Size(129, 23);
            txtväri.TabIndex = 4;
            // 
            // txtuusiomistaja
            // 
            txtuusiomistaja.Location = new System.Drawing.Point(363, 273);
            txtuusiomistaja.Name = "txtuusiomistaja";
            txtuusiomistaja.Size = new System.Drawing.Size(129, 23);
            txtuusiomistaja.TabIndex = 5;
            // 
            // txtvaihde
            // 
            txtvaihde.Location = new System.Drawing.Point(168, 110);
            txtvaihde.Name = "txtvaihde";
            txtvaihde.Size = new System.Drawing.Size(129, 23);
            txtvaihde.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(60, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(37, 19);
            label1.TabIndex = 7;
            label1.Text = "Nimi";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(212, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(51, 19);
            label2.TabIndex = 8;
            label2.Text = "Merkki";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(381, 9);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(38, 19);
            label3.TabIndex = 9;
            label3.Text = "Malli";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(60, 88);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(32, 19);
            label4.TabIndex = 10;
            label4.Text = "Väri";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(168, 88);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(140, 19);
            label5.TabIndex = 11;
            label5.Text = "vaihteiden lukumäärä";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(381, 251);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(91, 19);
            label6.TabIndex = 12;
            label6.Text = "Uusi omistaja";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new System.Drawing.Point(487, 6);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(284, 244);
            listBox1.TabIndex = 14;
            // 
            // btnpoista
            // 
            btnpoista.Location = new System.Drawing.Point(655, 256);
            btnpoista.Name = "btnpoista";
            btnpoista.Size = new System.Drawing.Size(109, 54);
            btnpoista.TabIndex = 15;
            btnpoista.Text = "Poista";
            btnpoista.UseVisualStyleBackColor = true;
            btnpoista.Click += btnpoista_Click;
            // 
            // btnvaito
            // 
            btnvaito.Location = new System.Drawing.Point(513, 256);
            btnvaito.Name = "btnvaito";
            btnvaito.Size = new System.Drawing.Size(109, 54);
            btnvaito.TabIndex = 16;
            btnvaito.Text = "Omistajan vaihto";
            btnvaito.UseVisualStyleBackColor = true;
            btnvaito.Click += btnvaito_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(776, 313);
            Controls.Add(btnvaito);
            Controls.Add(btnpoista);
            Controls.Add(listBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtvaihde);
            Controls.Add(txtuusiomistaja);
            Controls.Add(txtväri);
            Controls.Add(txtmalli);
            Controls.Add(txtmerkki);
            Controls.Add(txtOmistaja);
            Controls.Add(btnok);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            Name = "Form1";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Pyörärekisteri";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)txtvaihde).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.TextBox txtOmistaja;
        private System.Windows.Forms.TextBox txtmerkki;
        private System.Windows.Forms.TextBox txtmalli;
        private System.Windows.Forms.TextBox txtväri;
        private System.Windows.Forms.TextBox txtuusiomistaja;
        private System.Windows.Forms.NumericUpDown txtvaihde;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnpoista;
        private System.Windows.Forms.Button btnvaito;
    }
}

