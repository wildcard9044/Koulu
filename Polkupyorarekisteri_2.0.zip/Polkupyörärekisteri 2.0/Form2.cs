﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Polkupyörärekisteri_2._0.Form1;

namespace Polkupyörärekisteri_2._0
{
    public partial class Form2 : Form
    {
        private string dbPath;
        private List<Entry> entries;
        public Form2()
        {
            InitializeComponent();
            dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database.db");
            entries = new List<Entry>();
        }

        public class Entry
        {
            public int ID { get; set; }
            public string Käyttäjätunnus { get; set; }
            public string Salasana { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string valittukäyttäjä = txtkäyttäjä.Text;
            string valittusalasana = txtsalasana.Text;

            var regexItem = new Regex("^[a-zA-Z 0-9@?!]+$");

            if (regexItem.IsMatch(valittusalasana) == false || regexItem.IsMatch(valittukäyttäjä) == false)
            {
                MessageBox.Show("Kentissä voi olla vain kirjaimia tai numeroita");
            }
            else
            {
                int i = 0;
                string connectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";

                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string selectQuery = "SELECT ID, Käyttäjätunnus, Salasana FROM Käyttäjät";

                    using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                    {
                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Entry newEntry = new Entry();

                                if (!reader.IsDBNull(0))
                                {
                                    newEntry.ID = reader.GetInt32(0);
                                }

                                if (!reader.IsDBNull(1))
                                {
                                    newEntry.Käyttäjätunnus = reader.GetString(1);
                                }

                                if (!reader.IsDBNull(2))
                                {
                                    newEntry.Salasana = reader.GetString(2);
                                }
                                entries.Add(newEntry);

                                

                                foreach (Entry entry in entries)
                                {
                                    if (valittukäyttäjä == $"{entry.Käyttäjätunnus}" && valittusalasana == $"{entry.Salasana}")
                                    {

                                        if (i == 0)
                                        {
                                            Form1 NewForm = new Form1();
                                            NewForm.Show();
                                            this.Dispose(false);
                                        }
                                        i++;
                                    }
                                }
                            }
                        }
                    }
                    if (i == 0)
                    {
                        MessageBox.Show("Käyttäjätunnus tai salasana oli vääri");
                        txtsalasana.Text = "";
                    }

                }
            }


            
        }
    }
}
