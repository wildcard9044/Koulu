﻿namespace Polkupyörärekisteri_2._0
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new System.Windows.Forms.Button();
            txtkäyttäjä = new System.Windows.Forms.TextBox();
            txtsalasana = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(70, 187);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(177, 72);
            button1.TabIndex = 0;
            button1.Text = "Kirjaudu";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtkäyttäjä
            // 
            txtkäyttäjä.Location = new System.Drawing.Point(70, 35);
            txtkäyttäjä.Name = "txtkäyttäjä";
            txtkäyttäjä.Size = new System.Drawing.Size(177, 23);
            txtkäyttäjä.TabIndex = 1;
            // 
            // txtsalasana
            // 
            txtsalasana.Location = new System.Drawing.Point(70, 123);
            txtsalasana.Name = "txtsalasana";
            txtsalasana.PasswordChar = '•';
            txtsalasana.Size = new System.Drawing.Size(177, 23);
            txtsalasana.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(114, 92);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(87, 28);
            label1.TabIndex = 3;
            label1.Text = "Salasana";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(85, 4);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(147, 28);
            label2.TabIndex = 4;
            label2.Text = "Käyttäjä tunnus";
            // 
            // Form2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(328, 295);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtsalasana);
            Controls.Add(txtkäyttäjä);
            Controls.Add(button1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            Name = "Form2";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Kirjaudu sisään";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtkäyttäjä;
        private System.Windows.Forms.TextBox txtsalasana;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}